package ix.app.hidden

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

enum class Dest { Home, StatusBar, Hidden, Activities, Codes, Tweaks, Editor, Module }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            HiddenTheme {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { BootStore(ctx) }
    var dest by rememberSaveable { mutableStateOf(Dest.Home) }
    var root by remember { mutableStateOf<Boolean?>(null) }

    fun checkRoot() {
        scope.launch {
            root = null
            root = Shell.hasRoot()
        }
    }

    LaunchedEffect(Unit) { checkRoot() }

    BackHandler(enabled = dest != Dest.Home) {
        dest = if (dest == Dest.Activities || dest == Dest.Codes) Dest.Hidden else Dest.Home
    }

    when (dest) {
        Dest.Home -> HomeScreen(root = root, onRecheck = { checkRoot() }, go = { dest = it })
        Dest.StatusBar -> StatusBarScreen(store = store, onBack = { dest = Dest.Home })
        Dest.Hidden -> HiddenScreen(
            onBack = { dest = Dest.Home },
            openActivities = { dest = Dest.Activities },
            openCodes = { dest = Dest.Codes }
        )
        Dest.Activities -> ActivitiesScreen(onBack = { dest = Dest.Hidden })
        Dest.Codes -> CodesScreen(onBack = { dest = Dest.Hidden })
        Dest.Tweaks -> TweaksScreen(store = store, onBack = { dest = Dest.Home })
        Dest.Editor -> EditorScreen(store = store, onBack = { dest = Dest.Home })
        Dest.Module -> ModuleScreen(store = store, onBack = { dest = Dest.Home })
    }
}

@Composable
fun HomeScreen(root: Boolean?, onRecheck: () -> Unit, go: (Dest) -> Unit) {
    Page("Hidden settings", onBack = null) {
        item {
            SettingRow(
                title = "Root access",
                subtitle = when (root) {
                    null -> "Checking…"
                    true -> "Granted"
                    false -> "Not granted. Allow Hidden Settings in Magisk, then tap here"
                },
                dot = when (root) {
                    null -> NC.sub
                    true -> NC.green
                    false -> NC.pink
                },
                onClick = onRecheck
            )
        }
        item { Header("Tools") }
        item {
            SettingRow(
                "Status bar",
                "Hide SIM, operator, Wi-Fi, battery and other icons",
                dot = NC.green,
                onClick = { go(Dest.StatusBar) }
            )
        }
        item {
            SettingRow(
                "Hidden screens",
                "Developer options, testing menu, every system activity",
                dot = NC.orange,
                onClick = { go(Dest.Hidden) }
            )
        }
        item {
            SettingRow(
                "Tweaks",
                "Animations, screen density, private DNS and more",
                dot = NC.blue,
                onClick = { go(Dest.Tweaks) }
            )
        }
        item {
            SettingRow(
                "Settings editor",
                "Browse and edit system, secure and global values",
                dot = NC.pink,
                onClick = { go(Dest.Editor) }
            )
        }
        item {
            SettingRow(
                "Magisk module",
                "Re-apply your changes at every boot",
                dot = NC.yellow,
                onClick = { go(Dest.Module) }
            )
        }
    }
}
