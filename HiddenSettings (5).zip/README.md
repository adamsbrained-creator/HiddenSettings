# Hidden Settings

Root app (Kotlin + Jetpack Compose) with a Magisk module.

- Hide status bar icons (SIM, Wi-Fi, battery, ...)
- Open hidden system screens and every activity of Settings / System UI
- Tweaks (animations, density, private DNS, ...)
- Raw settings editor (system / secure / global)
- Magisk module re-applies your saved settings at every boot

## Build

Push this folder to a GitHub repo. The workflow in `.github/workflows/build.yml` runs on every push
(or start it by hand in the Actions tab) and publishes:

- `HiddenSettings.apk`: the app
- `HiddenSettings-Magisk-module.zip`: the module (it already contains the app)

Both are in the repo's **Releases** and in the run's **Artifacts**.

## Install

1. Flash `HiddenSettings-Magisk-module.zip` in Magisk > Modules, reboot. This installs the app as a system app.
   (Or just install `HiddenSettings.apk` and skip the module; you then lose the boot re-apply.)
2. Open the app and allow root in Magisk.

Every build is signed with the same key (`keystore/hidden.jks`), so new builds install over old ones.
Keep the repo **private**: the key is stored in it.
