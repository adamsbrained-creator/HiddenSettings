package ix.app.hidden

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val TABLES = listOf("system", "secure", "global")

@Composable
fun EditorScreen(store: BootStore, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var table by rememberSaveable { mutableStateOf("secure") }
    var query by rememberSaveable { mutableStateOf("") }
    var entries by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf<Pair<String, String>?>(null) }
    var adding by remember { mutableStateOf(false) }

    fun reload() {
        scope.launch {
            loading = true
            entries = Shell.listSettings(table)
            loading = false
        }
    }

    LaunchedEffect(table) { reload() }

    val shown = remember(entries, query) {
        val q = query.trim()
        if (q.isEmpty()) entries
        else entries.filter { it.first.contains(q, ignoreCase = true) || it.second.contains(q, ignoreCase = true) }
    }

    Page("Settings editor", onBack) {
        item {
            InfoCard(
                "These are the raw Android settings tables. A wrong value can break the UI or " +
                    "cause a bootloop, so only change what you understand."
            )
        }
        item {
            ChipRow {
                for (t in TABLES) {
                    Chip(t, table == t) { table = t }
                }
            }
        }
        item { InputField(query, { query = it }, "Search keys and values", FieldPad) }
        item {
            ButtonRow {
                PillButton("Add new key", primary = false) { adding = true }
                PillButton("Reload", primary = false) { reload() }
            }
        }
        item {
            Header(if (loading) "Loading…" else "${shown.size} of ${entries.size} values in $table")
        }
        items(shown, key = { it.first }) { (k, v) ->
            SettingRow(
                title = k,
                subtitle = v.ifEmpty { "(empty)" },
                subtitleMaxLines = 2,
                onClick = { editing = k to v }
            )
        }
    }

    val current = editing
    if (current != null) {
        EditDialog(
            table = table,
            initialKey = current.first,
            initialValue = current.second,
            isNew = false,
            store = store,
            onClose = { changed ->
                editing = null
                if (changed) reload()
            }
        )
    }
    if (adding) {
        EditDialog(
            table = table,
            initialKey = "",
            initialValue = "",
            isNew = true,
            store = store,
            onClose = { changed ->
                adding = false
                if (changed) reload()
            }
        )
    }
}

@Composable
private fun EditDialog(
    table: String,
    initialKey: String,
    initialValue: String,
    isNew: Boolean,
    store: BootStore,
    onClose: (Boolean) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(initialKey) }
    var value by remember { mutableStateOf(initialValue) }
    var persist by remember { mutableStateOf(store.has(table, initialKey)) }

    AlertDialog(
        onDismissRequest = { onClose(false) },
        containerColor = NC.surface2,
        title = { Text(if (isNew) "New value in $table" else key) },
        text = {
            Column {
                if (isNew) {
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it },
                        label = { Text("Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Value") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { persist = !persist },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = persist, onCheckedChange = { persist = it })
                    Text("Re-apply at every boot", color = Color.White)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val k = key.trim()
                if (k.isEmpty()) {
                    toast(ctx, "Key is empty")
                } else {
                    scope.launch {
                        val r = store.put(table, k, value, persist)
                        if (r.ok) onClose(true) else toast(ctx, "Failed: ${r.text}")
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (!isNew) {
                    TextButton(onClick = {
                        scope.launch {
                            val r = store.reset(table, key)
                            if (r.ok) onClose(true) else toast(ctx, "Failed: ${r.text}")
                        }
                    }) { Text("Delete") }
                }
                TextButton(onClick = { onClose(false) }) { Text("Cancel") }
            }
        }
    )
}
