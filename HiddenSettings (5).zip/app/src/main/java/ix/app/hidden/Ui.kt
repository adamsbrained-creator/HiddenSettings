package ix.app.hidden

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Colours inspired by the Nothing OS settings: pure black, soft pastel dots, one red accent. */
object NC {
    val bg = Color(0xFF000000)
    val surface = Color(0xFF111111)
    val surface2 = Color(0xFF1C1C1C)
    val sub = Color(0xFF9A9A9A)
    val red = Color(0xFFD71921)
    val green = Color(0xFFA8E6A1)
    val orange = Color(0xFFF2C79B)
    val blue = Color(0xFF7FA3D6)
    val pink = Color(0xFFF29B9B)
    val yellow = Color(0xFFF3F0A3)
    val cyan = Color(0xFF8FE3F0)
    val purple = Color(0xFFB9A9F0)
    val dots = listOf(green, orange, blue, pink, yellow, cyan, purple)
}

@Composable
fun HiddenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color.White,
            onPrimary = Color.Black,
            background = NC.bg,
            onBackground = Color.White,
            surface = NC.bg,
            onSurface = Color.White,
            surfaceVariant = NC.surface2,
            onSurfaceVariant = NC.sub,
            outline = Color(0xFF555555),
        ),
        content = content
    )
}

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

val FieldPad: Modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)

/** Big serif title, back arrow on top, scrolls as one list - like the Nothing settings pages. */
@Composable
fun Page(title: String, onBack: (() -> Unit)?, content: LazyListScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NC.bg)
            .statusBarsPadding()
            .imePadding(),
        contentPadding = PaddingValues(0.dp)
    ) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .align(Alignment.CenterStart)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            }
        }
        item {
            Text(
                text = title,
                color = Color.White,
                fontFamily = FontFamily.Serif,
                fontSize = 42.sp,
                lineHeight = 48.sp,
                modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 36.dp, bottom = 24.dp)
            )
        }
        content()
        item { Spacer(Modifier.navigationBarsPadding().height(32.dp)) }
    }
}

@Composable
fun SettingRow(
    title: String,
    subtitle: String? = null,
    dot: Color? = null,
    subtitleMaxLines: Int = 3,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val base = Modifier.fillMaxWidth()
    Row(
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot != null) {
            Box(
                Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(dot.copy(alpha = 0.30f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(dot)
                )
            }
            Spacer(Modifier.width(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 20.sp)
            if (subtitle != null) {
                Text(
                    subtitle,
                    color = NC.sub,
                    fontSize = 15.sp,
                    maxLines = subtitleMaxLines,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
fun SwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    dot: Color? = null,
    onChange: (Boolean) -> Unit,
) {
    SettingRow(
        title = title,
        subtitle = subtitle,
        dot = dot,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = NC.red,
                    checkedBorderColor = NC.red,
                    uncheckedThumbColor = NC.sub,
                    uncheckedTrackColor = NC.surface2,
                    uncheckedBorderColor = Color(0xFF444444),
                )
            )
        }
    )
}

@Composable
fun Header(text: String) {
    Text(
        text = text.uppercase(),
        color = NC.sub,
        fontSize = 13.sp,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 28.dp, bottom = 4.dp)
    )
}

@Composable
fun InfoCard(text: String) {
    Box(
        Modifier
            .padding(horizontal = 24.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(NC.surface)
            .padding(16.dp)
    ) {
        Text(text, color = NC.sub, fontSize = 14.sp, lineHeight = 20.sp)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Color.White else NC.surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(text, color = if (selected) Color.Black else Color.White, fontSize = 15.sp)
    }
}

@Composable
fun ChipRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun PillButton(text: String, primary: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (primary) Color.White else NC.surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.Black else Color.White, fontSize = 16.sp)
    }
}

@Composable
fun ButtonRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun InputField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    number: Boolean = false,
    singleLine: Boolean = true,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (number) KeyboardType.Number else KeyboardType.Text
        ),
        modifier = modifier.fillMaxWidth()
    )
}
