package ix.app.hidden

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

data class ShellResult(val code: Int, val out: String, val err: String) {
    val ok: Boolean get() = code == 0
    val text: String
        get() = listOf(out.trim(), err.trim()).filter { it.isNotEmpty() }.joinToString("\n")
}

/** Something we can start with `am start`: either a component (pkg/Class) or an intent action. */
data class Target(val component: String? = null, val action: String? = null)

object Shell {

    /** Wraps a value in single quotes so the shell treats it literally. */
    fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    /** Runs a command as root through `su -c`. */
    suspend fun su(cmd: String, timeoutSec: Long = 20): ShellResult = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su", "-c", cmd).start()
            p.outputStream.close()
            val out = StringBuilder()
            val err = StringBuilder()
            val t1 = Thread { out.append(p.inputStream.bufferedReader().readText()) }
            val t2 = Thread { err.append(p.errorStream.bufferedReader().readText()) }
            t1.start()
            t2.start()
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                ShellResult(-1, "", "Timed out")
            } else {
                t1.join(3000)
                t2.join(3000)
                ShellResult(p.exitValue(), out.toString(), err.toString())
            }
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "Could not run su")
        }
    }

    suspend fun hasRoot(): Boolean = su("id -u").out.trim() == "0"

    // ---- settings database (system / secure / global) ----

    suspend fun putSetting(table: String, key: String, value: String): ShellResult =
        su("settings put $table ${q(key)} ${q(value)}")

    suspend fun deleteSetting(table: String, key: String): ShellResult =
        su("settings delete $table ${q(key)}")

    suspend fun getSetting(table: String, key: String): String? {
        val r = su("settings get $table ${q(key)}")
        val v = r.out.trim()
        return if (!r.ok || v.isEmpty() || v == "null") null else v
    }

    suspend fun listSettings(table: String): List<Pair<String, String>> {
        val r = su("settings list $table", 30)
        return r.out.lines()
            .filter { it.contains('=') }
            .map { it.substringBefore('=') to it.substringAfter('=') }
            .sortedBy { it.first.lowercase() }
    }

    // ---- runtime resource overlays (Android 12+, no APK needed) ----

    /** Shell line that creates a string overlay and turns it on. Also used for the boot script. */
    fun fabricateCommand(target: String, name: String, resource: String, value: String): String =
        "cmd overlay fabricate --target ${q(target)} --name ${q(name)} ${q(resource)} 0x03 ${q(value)}" +
            " && cmd overlay enable --user 0 ${q("com.android.shell:$name")}"

    suspend fun fabricateString(target: String, name: String, resource: String, value: String): ShellResult =
        su(fabricateCommand(target, name, resource, value))

    suspend fun disableOverlay(name: String): ShellResult =
        su("cmd overlay disable --user 0 ${q("com.android.shell:$name")}")

    class ScanResult(val present: Set<String>?, val similar: List<String>)

    /**
     * Looks inside the package's resources.arsc for resource names, so we only overlay names that
     * really exist. [present] is null when the scan tools aren't usable on this phone.
     */
    suspend fun scanResourceNames(pkg: String, names: List<String>): ScanResult {
        val script =
            "APK=\$(pm path ${q(pkg)} | head -1 | cut -d: -f2); " +
                "F=/data/local/tmp/hs_scan.txt; " +
                "unzip -p \"\$APK\" resources.arsc 2>/dev/null | strings > \$F; " +
                "echo __n=\$(wc -l < \$F); " +
                "grep -x -E ${q(names.joinToString("|"))} \$F; " +
                "echo __similar; " +
                "grep -i -E 'emergency|kg_text|carrier_text|missing_sim' \$F | sort -u | head -30; " +
                "rm -f \$F"
        val r = su(script, 60)
        val lines = r.out.lines().map { it.trim() }
        val n = lines.firstOrNull { it.startsWith("__n=") }
            ?.removePrefix("__n=")?.trim()?.toIntOrNull() ?: 0
        if (n < 200) return ScanResult(null, emptyList())
        val sep = lines.indexOf("__similar")
        val head = if (sep >= 0) lines.subList(0, sep) else lines
        val tail = if (sep >= 0) lines.subList(sep + 1, lines.size) else emptyList()
        return ScanResult(head.filter { it in names }.toSet(), tail.filter { it.isNotEmpty() })
    }

    // ---- starting screens ----

    fun failed(r: ShellResult): Boolean =
        !r.ok || r.text.contains("Error", ignoreCase = true) || r.text.contains("Exception", ignoreCase = true)

    suspend fun startComponent(component: String): ShellResult = su("am start -n ${q(component)}")

    suspend fun startAction(action: String): ShellResult = su("am start -a ${q(action)}")

    /** Tries each target in order and stops at the first one that opens. */
    suspend fun launch(targets: List<Target>): ShellResult {
        var last = ShellResult(-1, "", "Nothing to launch")
        for (t in targets) {
            val comp = t.component
            val act = t.action
            val r = when {
                comp != null -> startComponent(comp)
                act != null -> startAction(act)
                else -> continue
            }
            if (!failed(r)) return r
            last = r
        }
        return last
    }
}
