package ix.app.hidden

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

data class ShellResult(val code: Int, val out: String, val err: String) {
    val ok: Boolean get() = code == 0
    val text: String
        get() = listOf(out.trim(), err.trim()).filter { it.isNotEmpty() }.joinToString("\n")
}

/** Something we can start with `am start`: either a component (pkg/Class) or an intent action. */
data class Target(val component: String? = null, val action: String? = null)

object Shell {

    /** Wraps a value in single quotes so the shell treats it literally. */
    fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    /** Runs a command as root through `su -c`. */
    suspend fun su(cmd: String, timeoutSec: Long = 20): ShellResult = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su", "-c", cmd).start()
            p.outputStream.close()
            val out = StringBuilder()
            val err = StringBuilder()
            val t1 = Thread { out.append(p.inputStream.bufferedReader().readText()) }
            val t2 = Thread { err.append(p.errorStream.bufferedReader().readText()) }
            t1.start()
            t2.start()
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                ShellResult(-1, "", "Timed out")
            } else {
                t1.join(3000)
                t2.join(3000)
                ShellResult(p.exitValue(), out.toString(), err.toString())
            }
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "Could not run su")
        }
    }

    suspend fun hasRoot(): Boolean = su("id -u").out.trim() == "0"

    // ---- settings database (system / secure / global) ----

    suspend fun putSetting(table: String, key: String, value: String): ShellResult =
        su("settings put $table ${q(key)} ${q(value)}")

    suspend fun deleteSetting(table: String, key: String): ShellResult =
        su("settings delete $table ${q(key)}")

    suspend fun getSetting(table: String, key: String): String? {
        val r = su("settings get $table ${q(key)}")
        val v = r.out.trim()
        return if (!r.ok || v.isEmpty() || v == "null") null else v
    }

    suspend fun listSettings(table: String): List<Pair<String, String>> {
        val r = su("settings list $table", 30)
        return r.out.lines()
            .filter { it.contains('=') }
            .map { it.substringBefore('=') to it.substringAfter('=') }
            .sortedBy { it.first.lowercase() }
    }

    // ---- starting screens ----

    fun failed(r: ShellResult): Boolean =
        !r.ok || r.text.contains("Error", ignoreCase = true) || r.text.contains("Exception", ignoreCase = true)

    suspend fun startComponent(component: String): ShellResult = su("am start -n ${q(component)}")

    suspend fun startAction(action: String): ShellResult = su("am start -a ${q(action)}")

    /** Tries each target in order and stops at the first one that opens. */
    suspend fun launch(targets: List<Target>): ShellResult {
        var last = ShellResult(-1, "", "Nothing to launch")
        for (t in targets) {
            val comp = t.component
            val act = t.action
            val r = when {
                comp != null -> startComponent(comp)
                act != null -> startAction(act)
                else -> continue
            }
            if (!failed(r)) return r
            last = r
        }
        return last
    }
}
