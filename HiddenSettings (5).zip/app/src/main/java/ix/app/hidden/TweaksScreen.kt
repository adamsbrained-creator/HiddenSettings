package ix.app.hidden

import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import kotlin.math.abs

private data class Tweak(
    val title: String,
    val sub: String,
    val table: String,
    val key: String,
    val on: String,
    val off: String,
)

private val TWEAKS = listOf(
    Tweak("Show touches", "Draw a dot where you tap", "system", "show_touches", "1", "0"),
    Tweak("Pointer location", "Touch coordinates overlay", "system", "pointer_location", "1", "0"),
    Tweak("Stay awake while charging", "Screen stays on when plugged in", "global", "stay_on_while_plugged_in", "3", "0"),
    Tweak("Developer options", "Show the Developer options menu", "global", "development_settings_enabled", "1", "0"),
    Tweak("Heads-up notifications", "Pop-up banners for new notifications", "global", "heads_up_notifications_enabled", "1", "0"),
    Tweak("Don't keep activities", "Destroy every screen as soon as you leave it", "global", "always_finish_activities", "1", "0"),
)

private val ANIMS = listOf(
    "Off" to 0f,
    "0.5×" to 0.5f,
    "1×" to 1f,
    "1.5×" to 1.5f,
    "2×" to 2f,
)

@Composable
fun TweaksScreen(store: BootStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val states = remember { mutableStateMapOf<String, Boolean>() }
    var anim by remember { mutableStateOf(1f) }
    var dnsMode by remember { mutableStateOf("opportunistic") }
    var dnsHost by remember { mutableStateOf("") }
    var densityInfo by remember { mutableStateOf("…") }
    var densityInput by remember { mutableStateOf("") }

    suspend fun loadDensity() {
        densityInfo = Shell.su("wm density").text.lines().joinToString(" · ")
    }

    LaunchedEffect(Unit) {
        for (t in TWEAKS) {
            states["${t.table}/${t.key}"] = Shell.getSetting(t.table, t.key) == t.on
        }
        anim = Shell.getSetting("global", "window_animation_scale")?.toFloatOrNull() ?: 1f
        dnsMode = Shell.getSetting("global", "private_dns_mode") ?: "opportunistic"
        dnsHost = Shell.getSetting("global", "private_dns_specifier") ?: ""
        loadDensity()
    }

    Page("Tweaks", onBack) {
        item { Header("Toggles") }
        items(TWEAKS, key = { "${it.table}/${it.key}" }) { t ->
            val id = "${t.table}/${t.key}"
            SwitchRow(
                title = t.title,
                subtitle = t.sub,
                checked = states[id] == true,
                onChange = { on ->
                    states[id] = on
                    scope.launch {
                        val r = store.put(t.table, t.key, if (on) t.on else t.off)
                        if (!r.ok) toast(ctx, r.text)
                    }
                }
            )
        }

        item { Header("Animation speed") }
        item {
            ChipRow {
                for ((label, value) in ANIMS) {
                    Chip(label, abs(anim - value) < 0.01f) {
                        anim = value
                        scope.launch {
                            for (k in listOf(
                                "window_animation_scale",
                                "transition_animation_scale",
                                "animator_duration_scale"
                            )) {
                                store.put("global", k, value.toString())
                            }
                        }
                    }
                }
            }
        }

        item { Header("Private DNS") }
        item {
            ChipRow {
                Chip("Off", dnsMode == "off") {
                    dnsMode = "off"
                    scope.launch { store.put("global", "private_dns_mode", "off") }
                }
                Chip("Automatic", dnsMode == "opportunistic") {
                    dnsMode = "opportunistic"
                    scope.launch { store.put("global", "private_dns_mode", "opportunistic") }
                }
                Chip("Custom", dnsMode == "hostname") {
                    dnsMode = "hostname"
                }
            }
        }
        if (dnsMode == "hostname") {
            item {
                InputField(dnsHost, { dnsHost = it }, "Provider hostname (e.g. dns.google)", FieldPad)
            }
            item {
                ButtonRow {
                    PillButton("Apply") {
                        val host = dnsHost.trim()
                        if (host.isEmpty()) {
                            toast(ctx, "Enter a hostname first")
                        } else {
                            scope.launch {
                                store.put("global", "private_dns_specifier", host)
                                val r = store.put("global", "private_dns_mode", "hostname")
                                toast(ctx, if (r.ok) "Applied" else r.text)
                            }
                        }
                    }
                }
            }
        }

        item { Header("Screen density") }
        item { InfoCard("Current: $densityInfo\nTypical phones use 320 to 480. Values outside 200 to 800 are blocked.") }
        item { InputField(densityInput, { densityInput = it }, "New density (dpi)", FieldPad, number = true) }
        item {
            ButtonRow {
                PillButton("Apply") {
                    val n = densityInput.trim().toIntOrNull()
                    if (n == null || n < 200 || n > 800) {
                        toast(ctx, "Enter a number between 200 and 800")
                    } else {
                        scope.launch {
                            Shell.su("wm density $n")
                            loadDensity()
                        }
                    }
                }
                PillButton("Reset", primary = false) {
                    scope.launch {
                        Shell.su("wm density reset")
                        loadDensity()
                    }
                }
            }
        }
    }
}
