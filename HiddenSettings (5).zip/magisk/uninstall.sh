#!/system/bin/sh
# Runs when the module is removed in Magisk
rm -rf /data/adb/hidden_settings
