package ix.app.hidden

import android.content.pm.PackageManager
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val S = "com.android.settings"

private data class HiddenItem(val title: String, val sub: String, val targets: List<Target>)

private val ITEMS = listOf(
    HiddenItem(
        "Developer options", "Debugging, animations, USB and more",
        listOf(
            Target(action = "android.settings.APPLICATION_DEVELOPMENT_SETTINGS"),
            Target(component = "$S/.Settings\$DevelopmentSettingsDashboardActivity")
        )
    ),
    HiddenItem(
        "Phone info / testing menu", "Radio info, network type, signal details",
        listOf(
            Target(component = "com.android.phone/.settings.RadioInfo"),
            Target(component = "$S/.RadioInfo"),
            Target(component = "$S/.TestingSettings")
        )
    ),
    HiddenItem(
        "Wireless debugging", "Pair and connect adb over Wi-Fi",
        listOf(Target(component = "$S/.Settings\$WirelessDebuggingActivity"))
    ),
    HiddenItem(
        "Notification log", "History of every notification posted",
        listOf(Target(component = "$S/.Settings\$NotificationStationActivity"))
    ),
    HiddenItem(
        "System UI Tuner", "Hidden status bar tuner (not on every ROM)",
        listOf(Target(component = "com.android.systemui/.tuner.TunerActivity"))
    ),
    HiddenItem(
        "Special app access", "Overlay, write settings, unknown sources and more",
        listOf(Target(component = "$S/.Settings\$SpecialAccessSettingsActivity"))
    ),
    HiddenItem(
        "Usage access", "Apps allowed to read usage stats",
        listOf(Target(action = "android.settings.USAGE_ACCESS_SETTINGS"))
    ),
    HiddenItem(
        "Battery optimization", "Apps exempt from battery restrictions",
        listOf(Target(action = "android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"))
    ),
    HiddenItem(
        "Install unknown apps", "Which apps may install APKs",
        listOf(Target(action = "android.settings.MANAGE_UNKNOWN_APP_SOURCES"))
    ),
    HiddenItem(
        "Display over other apps", "Overlay permission list",
        listOf(Target(action = "android.settings.action.MANAGE_OVERLAY_PERMISSION"))
    ),
    HiddenItem(
        "Modify system settings", "Apps allowed to write system settings",
        listOf(Target(action = "android.settings.action.MANAGE_WRITE_SETTINGS"))
    ),
    HiddenItem(
        "All files access", "Apps with full storage access",
        listOf(Target(action = "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"))
    ),
    HiddenItem(
        "Notification access", "Apps that can read notifications",
        listOf(Target(action = "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    ),
    HiddenItem(
        "APN settings", "Mobile data access points",
        listOf(Target(action = "android.settings.APN_SETTINGS"))
    ),
    HiddenItem(
        "Mobile network operators", "Network operator selection and roaming",
        listOf(
            Target(action = "android.settings.NETWORK_OPERATOR_SETTINGS"),
            Target(action = "android.settings.DATA_ROAMING_SETTINGS")
        )
    ),
    HiddenItem(
        "Device admin apps", "Apps with device administrator rights",
        listOf(Target(component = "$S/.Settings\$DeviceAdminSettingsActivity"))
    ),
)

@Composable
fun HiddenScreen(onBack: () -> Unit, openActivities: () -> Unit, openCodes: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    Page("Hidden screens", onBack) {
        item {
            SettingRow(
                "All system activities",
                "Browse and open every screen inside Settings, System UI and more",
                dot = NC.red,
                onClick = openActivities
            )
        }
        item {
            SettingRow(
                "Secret codes",
                "Dialer codes like *#*#4636#*#* without the dialer",
                dot = NC.purple,
                onClick = openCodes
            )
        }
        item { Header("Quick access") }
        itemsIndexed(ITEMS) { i, h ->
            SettingRow(
                title = h.title,
                subtitle = h.sub,
                dot = NC.dots[i % NC.dots.size],
                onClick = {
                    scope.launch {
                        val r = Shell.launch(h.targets)
                        if (Shell.failed(r)) toast(ctx, "Not available on this ROM")
                    }
                }
            )
        }
    }
}

private suspend fun loadActivities(pm: PackageManager, pkg: String): List<String>? =
    withContext(Dispatchers.IO) {
        try {
            val flags = (PackageManager.GET_ACTIVITIES or PackageManager.MATCH_DISABLED_COMPONENTS).toLong()
            val info = pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags))
            info.activities?.map { it.name }?.distinct()?.sorted() ?: emptyList()
        } catch (e: Exception) {
            null
        }
    }

@Composable
fun ActivitiesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pkg by rememberSaveable { mutableStateOf("com.android.settings") }
    var query by rememberSaveable { mutableStateOf("") }
    var all by remember { mutableStateOf<List<String>>(emptyList()) }
    var status by remember { mutableStateOf("Loading…") }

    fun load() {
        scope.launch {
            val list = loadActivities(ctx.packageManager, pkg.trim())
            if (list == null) {
                all = emptyList()
                status = "Package not found"
            } else {
                all = list
                status = "${list.size} activities"
            }
        }
    }

    LaunchedEffect(Unit) { load() }

    val shown = remember(all, query) {
        val q = query.trim()
        if (q.isEmpty()) all else all.filter { it.contains(q, ignoreCase = true) }
    }

    Page("All activities", onBack) {
        item {
            InfoCard(
                "Tap an entry to open it with root. Some screens need extra data and will close " +
                    "right away, that's normal. Not every entry is meant to be opened directly."
            )
        }
        item {
            ChipRow {
                Chip("Settings", pkg == "com.android.settings") {
                    pkg = "com.android.settings"; load()
                }
                Chip("System UI", pkg == "com.android.systemui") {
                    pkg = "com.android.systemui"; load()
                }
                Chip("Phone", pkg == "com.android.phone") {
                    pkg = "com.android.phone"; load()
                }
            }
        }
        item {
            OutlinedTextField(
                value = pkg,
                onValueChange = { pkg = it },
                label = { Text("Package name") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { load() }),
                modifier = FieldPad.then(Modifier)
            )
        }
        item {
            InputField(query, { query = it }, "Search ($status)", FieldPad)
        }
        items(shown, key = { it }) { cls ->
            SettingRow(
                title = cls.substringAfterLast('.'),
                subtitle = cls,
                subtitleMaxLines = 2,
                onClick = {
                    scope.launch {
                        val r = Shell.startComponent("${pkg.trim()}/$cls")
                        if (Shell.failed(r)) {
                            val line = r.text.lines().firstOrNull { it.isNotBlank() } ?: "failed"
                            toast(ctx, "Couldn't open: $line")
                        }
                    }
                }
            )
        }
    }
}

private val CODES = listOf(
    "4636" to "Phone information / testing menu",
    "6484" to "Factory test menu (Nothing phones)",
)

@Composable
fun CodesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }

    fun send(c: String) {
        val digits = c.trim()
        if (digits.isEmpty()) return
        scope.launch {
            Shell.su(
                "am broadcast -f 0x01000000 -a android.provider.Telephony.SECRET_CODE " +
                    "-d ${Shell.q("android_secret_code://$digits")}"
            )
            toast(ctx, "Sent. If nothing opened, this code doesn't exist on your ROM")
        }
    }

    Page("Secret codes", onBack) {
        item {
            InfoCard(
                "Enter only the digits between *#*# and #*#*. For example *#*#4636#*#* is just 4636. " +
                    "Codes that need the dialer itself (like *#06#) won't work here."
            )
        }
        itemsIndexed(CODES) { i, (c, label) ->
            SettingRow(
                title = c,
                subtitle = label,
                dot = NC.dots[i % NC.dots.size],
                onClick = { send(c) }
            )
        }
        item { Header("Your own code") }
        item { InputField(code, { code = it }, "Digits only", FieldPad, number = true) }
        item {
            ButtonRow { PillButton("Send code") { send(code) } }
        }
    }
}
