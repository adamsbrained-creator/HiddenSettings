package ix.app.hidden

import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

private data class Slot(val id: String, val label: String, val sub: String = "")

private val SLOTS = listOf(
    Slot("mobile", "Mobile signal & data", "Signal bars and the 4G / 5G indicator"),
    Slot("no_sim", "No SIM icon", "Shown when no SIM card is detected"),
    Slot("ims_calling", "VoLTE / IMS calling"),
    Slot("call_strength", "Call strength"),
    Slot("wifi", "Wi-Fi"),
    Slot("airplane", "Airplane mode"),
    Slot("battery", "Battery icon"),
    Slot("clock", "Clock"),
    Slot("bluetooth", "Bluetooth"),
    Slot("alarm_clock", "Alarm clock"),
    Slot("zen", "Do not disturb"),
    Slot("volume", "Volume / vibrate mode"),
    Slot("rotate", "Auto-rotate lock"),
    Slot("headset", "Headset"),
    Slot("nfc", "NFC"),
    Slot("hotspot", "Hotspot"),
    Slot("location", "Location"),
    Slot("vpn", "VPN"),
    Slot("cast", "Screen cast"),
    Slot("data_saver", "Data saver"),
    Slot("sync_failing", "Sync problem"),
    Slot("ethernet", "Ethernet"),
    Slot("managed_profile", "Work profile"),
    Slot("sensors_off", "Sensors off"),
)

private const val UI = "com.android.systemui"
private const val FW = "android"

private class CarrierOverlay(val id: String, val pkg: String, val name: String)

// Applied every time, exactly like the first version (that one removed "No SIM" on your phone).
private val BASE_OVERLAYS = listOf(
    CarrierOverlay("hs_cr_nosim", UI, "keyguard_missing_sim_message_short"),
    CarrierOverlay("hs_cr_nosim_long", UI, "keyguard_missing_sim_message"),
    CarrierOverlay("hs_cr_emerg", FW, "emergency_calls_only"),
    CarrierOverlay("hs_cr_sep", FW, "kg_text_message_separator"),
    CarrierOverlay("hs_cr_default", FW, "lockscreen_carrier_default"),
)

// Extra names that are tried in the other package too, but only where the scan finds them.
private val EXTRA_NAMES = listOf(
    "keyguard_missing_sim_message_short",
    "keyguard_missing_sim_message",
    "emergency_calls_only",
    "kg_text_message_separator",
    "lockscreen_carrier_default",
)

private fun extraId(pkg: String, name: String) = "hs_cr_${if (pkg == UI) "ui" else "fw"}_$name"

private suspend fun applyOverlay(store: BootStore, o: CarrierOverlay, label: String, lines: MutableList<String>) {
    val res = "${o.pkg}:string/${o.name}"
    val r = Shell.fabricateString(o.pkg, o.id, res, " ")
    if (Shell.failed(r)) {
        val why = r.text.lines().firstOrNull { it.isNotBlank() } ?: "failed"
        lines.add("✗ $label: ${o.name} ($why)")
    } else {
        store.putCommand(o.id, Shell.fabricateCommand(o.pkg, o.id, res, " "))
        lines.add("✓ $label: ${o.name}")
    }
}

private suspend fun hideCarrierText(store: BootStore): String {
    val lines = mutableListOf<String>()
    for (o in BASE_OVERLAYS) {
        applyOverlay(store, o, if (o.pkg == UI) "System UI" else "Android", lines)
    }
    lines.add("")
    for (pkg in listOf(UI, FW)) {
        val label = if (pkg == UI) "System UI" else "Android"
        val scan = Shell.scanResourceNames(pkg, EXTRA_NAMES)
        val present = scan.present
        if (present == null) {
            lines.add("Scan of $label: not usable (${scan.count} strings read)")
            continue
        }
        lines.add("Scan of $label: ${scan.count} strings, has ${present.size} of ${EXTRA_NAMES.size} names" +
            (if (present.isNotEmpty()) ": ${present.joinToString()}" else ""))
        for (name in EXTRA_NAMES) {
            if (name !in present) continue
            if (BASE_OVERLAYS.any { it.pkg == pkg && it.name == name }) continue
            applyOverlay(store, CarrierOverlay(extraId(pkg, name), pkg, name), label, lines)
        }
        if (scan.similar.isNotEmpty()) {
            lines.add("Similar names in $label: ${scan.similar.take(12).joinToString()}")
        }
    }
    lines.add("")
    lines.add("Lock the phone and check the top. If text is still there, send me this list.")
    return lines.joinToString("\n")
}

private suspend fun restoreCarrierText(store: BootStore) {
    val ids = BASE_OVERLAYS.map { it.id } +
        listOf(UI, FW).flatMap { pkg -> EXTRA_NAMES.map { extraId(pkg, it) } }
    for (id in ids) {
        Shell.disableOverlay(id)
        store.removeCommand(id)
    }
}

@Composable
fun StatusBarScreen(store: BootStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var hidden by remember { mutableStateOf<Set<String>>(emptySet()) }
    var raw by remember { mutableStateOf("") }
    var battPct by remember { mutableStateOf(false) }
    var clockSec by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf("") }
    var carrierLog by remember { mutableStateOf(store.carrierLog) }
    var busy by remember { mutableStateOf(false) }
    var hookOn by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val v = Shell.getSetting("secure", "icon_blacklist") ?: ""
        raw = v
        hidden = v.split(",").map { it.trim() }.filter { it.isNotEmpty() && it != "none" }.toSet()
        battPct = Shell.getSetting("system", "status_bar_show_battery_percent") == "1"
        clockSec = Shell.getSetting("secure", "clock_seconds") == "1"
        hookOn = Shell.getSetting("secure", "hs_hide_carrier") == "1"
    }

    fun applyHidden(newSet: Set<String>) {
        hidden = newSet
        scope.launch {
            // An empty value would make Android fall back to its default list, so use a dummy slot.
            val value = if (newSet.isEmpty()) "none" else newSet.joinToString(",")
            val r = store.put("secure", "icon_blacklist", value)
            raw = value
            if (!r.ok) toast(ctx, "Failed: ${r.text}")
        }
    }

    val known = SLOTS.map { it.id }.toSet()

    Page("Status bar", onBack) {
        item {
            InfoCard(
                "Switch ON = icon hidden. Changes apply instantly. " +
                    "If something doesn't update, use \"Restart System UI\" at the bottom."
            )
        }
        item { Header("Hide icons") }
        items(SLOTS, key = { it.id }) { s ->
            SwitchRow(
                title = s.label,
                subtitle = s.sub.ifBlank { null },
                checked = hidden.contains(s.id),
                onChange = { on -> applyHidden(if (on) hidden + s.id else hidden - s.id) }
            )
        }

        val extras = hidden.filter { it !in known }
        items(extras, key = { "custom_$it" }) { id ->
            SwitchRow(
                title = "Custom slot: $id",
                checked = true,
                onChange = { applyHidden(hidden - id) }
            )
        }

        item { Header("Add a slot by name") }
        item {
            InputField(custom, { custom = it }, "Slot name (e.g. operator)", FieldPad)
        }
        item {
            ButtonRow {
                PillButton("Hide this slot") {
                    val name = custom.trim().lowercase()
                    if (name.isNotEmpty()) {
                        applyHidden(hidden + name)
                        custom = ""
                    }
                }
            }
        }

        item { Header("Extras") }
        item {
            SwitchRow(
                title = "Battery percentage",
                subtitle = "Show the number next to the battery icon",
                checked = battPct,
                onChange = { on ->
                    battPct = on
                    scope.launch {
                        val r = store.put("system", "status_bar_show_battery_percent", if (on) "1" else "0")
                        if (!r.ok) toast(ctx, r.text)
                    }
                }
            )
        }
        item {
            SwitchRow(
                title = "Seconds in the clock",
                subtitle = "May not be supported on every ROM",
                checked = clockSec,
                onChange = { on ->
                    clockSec = on
                    scope.launch {
                        val r = store.put("secure", "clock_seconds", if (on) "1" else "0")
                        if (!r.ok) toast(ctx, r.text)
                    }
                }
            )
        }

        item { Header("Lock screen carrier text") }
        item {
            SwitchRow(
                title = "Hide carrier label (LSPosed)",
                subtitle = "Blanks the whole \"No SIM / Emergency calls only\" label in System UI",
                checked = hookOn,
                dot = NC.red,
                onChange = { on ->
                    hookOn = on
                    scope.launch {
                        val r = store.put("secure", "hs_hide_carrier", if (on) "1" else "0")
                        if (!r.ok) toast(ctx, r.text)
                        Shell.su("pkill -f com.android.system[u]i")
                    }
                }
            )
        }
        item {
            InfoCard(
                "One-time setup: open LSPosed > Modules > Hidden Settings, turn it on, tick System UI " +
                    "as scope, then restart System UI (or reboot). After that this switch works instantly."
            )
        }
        item { Header("Overlay method (experimental)") }
        item {
            InfoCard(
                "The \"No SIM — Emergency calls only\" line on the lock screen is a separate carrier label, " +
                    "not a status bar icon, so the switches above can't remove it. " +
                    "This replaces its text with blank spaces using a system overlay. " +
                    "It's an experiment: the list below shows which parts your ROM accepted."
            )
        }
        item {
            ButtonRow {
                PillButton(if (busy) "Working…" else "Hide carrier text") {
                    if (!busy) {
                        busy = true
                        scope.launch {
                            carrierLog = hideCarrierText(store)
                            store.carrierLog = carrierLog
                            Shell.su("pkill -f com.android.system[u]i")
                            busy = false
                        }
                    }
                }
                PillButton("Restore", primary = false) {
                    if (!busy) {
                        busy = true
                        scope.launch {
                            restoreCarrierText(store)
                            carrierLog = "Restored. Lock the phone again to check."
                            store.carrierLog = carrierLog
                            Shell.su("pkill -f com.android.system[u]i")
                            busy = false
                        }
                    }
                }
            }
        }
        if (carrierLog.isNotEmpty()) {
            item { InfoCard(carrierLog) }
        }

        item { Header("Maintenance") }
        item {
            ButtonRow {
                PillButton("Show all icons", primary = false) { applyHidden(emptySet()) }
                PillButton("Restart System UI", primary = false) {
                    scope.launch {
                        Shell.su("pkill -f com.android.system[u]i")
                        toast(ctx, "System UI restarting")
                    }
                }
            }
        }
        item {
            ButtonRow {
                PillButton("Reset to ROM default", primary = false) {
                    scope.launch {
                        store.reset("secure", "icon_blacklist")
                        hidden = emptySet()
                        raw = ""
                        toast(ctx, "Back to default")
                    }
                }
            }
        }
        item {
            InfoCard("Current icon_blacklist value: ${raw.ifEmpty { "(not set)" }}")
        }
    }
}
