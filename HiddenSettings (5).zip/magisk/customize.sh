#!/system/bin/sh
# Magisk module installer script (runs while flashing)

ui_print "- Hidden Settings"
ui_print "- The app is installed as a system app after the next reboot"
ui_print "- Settings saved in the app are re-applied after every boot"

mkdir -p /data/adb/hidden_settings

set_perm_recursive "$MODPATH/system/app" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
