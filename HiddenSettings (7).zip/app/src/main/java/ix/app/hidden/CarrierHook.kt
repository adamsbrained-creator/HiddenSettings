package ix.app.hidden

import android.provider.Settings
import android.view.View
import android.widget.TextView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.Collections
import java.util.WeakHashMap

/**
 * LSPosed part of the app. It runs inside System UI and blanks the carrier label
 * ("No SIM - Emergency calls only") whenever the secure setting hs_hide_carrier is 1.
 * The app flips that setting with its switch on the Status bar page.
 */
class CarrierHook : IXposedHookLoadPackage {

    private val decided: MutableMap<View, Boolean> = Collections.synchronizedMap(WeakHashMap())

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.android.systemui") return
        try {
            XposedHelpers.findAndHookMethod(
                TextView::class.java,
                "setText",
                CharSequence::class.java,
                TextView.BufferType::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                        try {
                            val v = param.thisObject as? TextView ?: return
                            if (isCarrierText(v) && hideWanted(v)) {
                                param.args[0] = ""
                            }
                        } catch (e: Throwable) {
                            // never break System UI because of this hook
                        }
                    }
                }
            )
            XposedBridge.log("HiddenSettings: carrier text hook installed in System UI")
        } catch (e: Throwable) {
            XposedBridge.log("HiddenSettings: could not hook: $e")
        }
    }

    /** True for the carrier label view: class name or view id contains "carrier text". */
    private fun isCarrierText(v: TextView): Boolean {
        val known = decided[v]
        if (known != null) return known
        var yes = v.javaClass.name.contains("CarrierText", ignoreCase = true)
        if (!yes && v.id != View.NO_ID) {
            yes = try {
                v.resources.getResourceEntryName(v.id).contains("carrier_text", ignoreCase = true)
            } catch (e: Throwable) {
                false
            }
        }
        decided[v] = yes
        return yes
    }

    private fun hideWanted(v: TextView): Boolean =
        try {
            Settings.Secure.getInt(v.context.contentResolver, "hs_hide_carrier", 0) == 1
        } catch (e: Throwable) {
            false
        }
}
