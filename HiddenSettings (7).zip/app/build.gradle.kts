plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ix.app.hidden"
    compileSdk = 35

    defaultConfig {
        applicationId = "ix.app.hidden"
        minSdk = 33
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }

    // Fixed signing key stored in the repo, so every new build can be installed
    // over the previous one without uninstalling (and losing app data).
    signingConfigs {
        create("fixed") {
            storeFile = rootProject.file("keystore/hidden.jks")
            storeType = "pkcs12"
            storePassword = "hiddensettings"
            keyAlias = "hidden"
            keyPassword = "hiddensettings"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Only for compiling the LSPosed hook; LSPosed provides the real classes at runtime.
    compileOnly(project(":xposed-stub"))
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
