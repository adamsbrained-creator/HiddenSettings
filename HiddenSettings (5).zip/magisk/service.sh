#!/system/bin/sh
# Runs late in boot. Re-applies everything saved by the Hidden Settings app.

MODDIR=${0%/*}
DIR=/data/adb/hidden_settings
CONF=$DIR/boot.sh
LOG=$DIR/boot.log

mkdir -p "$DIR"

# wait until Android has fully booted
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done
sleep 10

{
  echo "Boot apply: $(date)"
  if [ -f "$CONF" ]; then
    sh "$CONF"
    echo "First pass done (exit $?)"
    # some ROMs reset values while System UI starts, so apply once more
    sleep 30
    sh "$CONF"
    echo "Second pass done (exit $?)"
  else
    echo "Nothing saved yet ($CONF not found)"
  fi
} > "$LOG" 2>&1
