package de.robv.android.xposed.callbacks;

/** Compile-time stub. LSPosed provides the real class at runtime. */
public abstract class XC_LoadPackage {
    public static class LoadPackageParam {
        public String packageName;
        public String processName;
        public ClassLoader classLoader;
        public boolean isFirstApplication;
    }
}
