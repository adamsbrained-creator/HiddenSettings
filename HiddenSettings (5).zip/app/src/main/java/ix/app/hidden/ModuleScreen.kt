package ix.app.hidden

import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

@Composable
fun ModuleScreen(store: BootStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var installed by remember { mutableStateOf<Boolean?>(null) }
    var log by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(store.enabled) }
    var saved by remember { mutableStateOf(store.entries()) }

    fun refresh() {
        scope.launch {
            installed = Shell.su("test -d /data/adb/modules/hidden_settings && echo yes").out.trim() == "yes"
            log = Shell.su("cat /data/adb/hidden_settings/boot.log 2>/dev/null").out.trim()
            saved = store.entries()
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Page("Magisk module", onBack) {
        item {
            SettingRow(
                title = "Module status",
                subtitle = when (installed) {
                    null -> "Checking…"
                    true -> "Installed. Your saved settings are re-applied after every boot"
                    false -> "Not installed. Flash HiddenSettings-Magisk-module.zip in Magisk > Modules, then reboot"
                },
                dot = when (installed) {
                    null -> NC.sub
                    true -> NC.green
                    false -> NC.orange
                },
                onClick = { refresh() }
            )
        }
        item {
            SwitchRow(
                title = "Re-apply at boot",
                subtitle = "Master switch for everything listed below",
                checked = enabled,
                onChange = { on ->
                    enabled = on
                    store.enabled = on
                    scope.launch { store.sync() }
                }
            )
        }
        item {
            ButtonRow {
                PillButton("Apply now") {
                    scope.launch {
                        store.sync()
                        val r = Shell.su("sh /data/adb/hidden_settings/boot.sh")
                        toast(ctx, if (r.ok) "Applied" else "Failed: ${r.text}")
                        refresh()
                    }
                }
            }
        }

        item { Header("Saved for boot (tap to forget)") }
        if (saved.isEmpty()) {
            item { InfoCard("Nothing saved yet. Anything you change in the app is added here automatically.") }
        }
        items(saved, key = { "${it.first}|${it.second}" }) { (table, key, value) ->
            SettingRow(
                title = key,
                subtitle = "$table = $value",
                subtitleMaxLines = 2,
                onClick = {
                    scope.launch {
                        store.forget(table, key)
                        saved = store.entries()
                    }
                }
            )
        }

        item { Header("Last boot log") }
        item { InfoCard(log.ifEmpty { "(empty)" }) }
    }
}
