package de.robv.android.xposed;

/** Compile-time stub. LSPosed provides the real class at runtime. */
public interface IXposedMod {
}
