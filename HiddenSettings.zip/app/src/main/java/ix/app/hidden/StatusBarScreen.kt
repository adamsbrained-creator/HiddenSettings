package ix.app.hidden

import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

private data class Slot(val id: String, val label: String, val sub: String = "")

private val SLOTS = listOf(
    Slot("mobile", "Mobile signal & data", "Signal bars and the 4G / 5G indicator"),
    Slot("no_sim", "No SIM icon", "Shown when no SIM card is detected"),
    Slot("ims_calling", "VoLTE / IMS calling"),
    Slot("call_strength", "Call strength"),
    Slot("wifi", "Wi-Fi"),
    Slot("airplane", "Airplane mode"),
    Slot("battery", "Battery icon"),
    Slot("clock", "Clock"),
    Slot("bluetooth", "Bluetooth"),
    Slot("alarm_clock", "Alarm clock"),
    Slot("zen", "Do not disturb"),
    Slot("volume", "Volume / vibrate mode"),
    Slot("rotate", "Auto-rotate lock"),
    Slot("headset", "Headset"),
    Slot("nfc", "NFC"),
    Slot("hotspot", "Hotspot"),
    Slot("location", "Location"),
    Slot("vpn", "VPN"),
    Slot("cast", "Screen cast"),
    Slot("data_saver", "Data saver"),
    Slot("sync_failing", "Sync problem"),
    Slot("ethernet", "Ethernet"),
    Slot("managed_profile", "Work profile"),
    Slot("sensors_off", "Sensors off"),
)

@Composable
fun StatusBarScreen(store: BootStore, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var hidden by remember { mutableStateOf<Set<String>>(emptySet()) }
    var raw by remember { mutableStateOf("") }
    var battPct by remember { mutableStateOf(false) }
    var clockSec by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val v = Shell.getSetting("secure", "icon_blacklist") ?: ""
        raw = v
        hidden = v.split(",").map { it.trim() }.filter { it.isNotEmpty() && it != "none" }.toSet()
        battPct = Shell.getSetting("system", "status_bar_show_battery_percent") == "1"
        clockSec = Shell.getSetting("secure", "clock_seconds") == "1"
    }

    fun applyHidden(newSet: Set<String>) {
        hidden = newSet
        scope.launch {
            // An empty value would make Android fall back to its default list, so use a dummy slot.
            val value = if (newSet.isEmpty()) "none" else newSet.joinToString(",")
            val r = store.put("secure", "icon_blacklist", value)
            raw = value
            if (!r.ok) toast(ctx, "Failed: ${r.text}")
        }
    }

    val known = SLOTS.map { it.id }.toSet()

    Page("Status bar", onBack) {
        item {
            InfoCard(
                "Switch ON = icon hidden. Changes apply instantly. " +
                    "If something doesn't update, use \"Restart System UI\" at the bottom."
            )
        }
        item { Header("Hide icons") }
        items(SLOTS, key = { it.id }) { s ->
            SwitchRow(
                title = s.label,
                subtitle = s.sub.ifBlank { null },
                checked = hidden.contains(s.id),
                onChange = { on -> applyHidden(if (on) hidden + s.id else hidden - s.id) }
            )
        }

        val extras = hidden.filter { it !in known }
        items(extras, key = { "custom_$it" }) { id ->
            SwitchRow(
                title = "Custom slot: $id",
                checked = true,
                onChange = { applyHidden(hidden - id) }
            )
        }

        item { Header("Add a slot by name") }
        item {
            InputField(custom, { custom = it }, "Slot name (e.g. operator)", FieldPad)
        }
        item {
            ButtonRow {
                PillButton("Hide this slot") {
                    val name = custom.trim().lowercase()
                    if (name.isNotEmpty()) {
                        applyHidden(hidden + name)
                        custom = ""
                    }
                }
            }
        }

        item { Header("Extras") }
        item {
            SwitchRow(
                title = "Battery percentage",
                subtitle = "Show the number next to the battery icon",
                checked = battPct,
                onChange = { on ->
                    battPct = on
                    scope.launch {
                        val r = store.put("system", "status_bar_show_battery_percent", if (on) "1" else "0")
                        if (!r.ok) toast(ctx, r.text)
                    }
                }
            )
        }
        item {
            SwitchRow(
                title = "Seconds in the clock",
                subtitle = "May not be supported on every ROM",
                checked = clockSec,
                onChange = { on ->
                    clockSec = on
                    scope.launch {
                        val r = store.put("secure", "clock_seconds", if (on) "1" else "0")
                        if (!r.ok) toast(ctx, r.text)
                    }
                }
            )
        }

        item { Header("Operator name") }
        item {
            InfoCard(
                "On most ROMs the carrier name isn't a normal status bar icon, so it may ignore this list. " +
                    "Workaround that usually works: Settings > Network & internet > SIMs, " +
                    "open your SIM and rename it to a single space. " +
                    "Tell me what your phone shows and I'll add a proper switch for it."
            )
        }

        item { Header("Maintenance") }
        item {
            ButtonRow {
                PillButton("Show all icons", primary = false) { applyHidden(emptySet()) }
                PillButton("Restart System UI", primary = false) {
                    scope.launch {
                        Shell.su("pkill -f com.android.system[u]i")
                        toast(ctx, "System UI restarting")
                    }
                }
            }
        }
        item {
            ButtonRow {
                PillButton("Reset to ROM default", primary = false) {
                    scope.launch {
                        store.reset("secure", "icon_blacklist")
                        hidden = emptySet()
                        raw = ""
                        toast(ctx, "Back to default")
                    }
                }
            }
        }
        item {
            InfoCard("Current icon_blacklist value: ${raw.ifEmpty { "(not set)" }}")
        }
    }
}
